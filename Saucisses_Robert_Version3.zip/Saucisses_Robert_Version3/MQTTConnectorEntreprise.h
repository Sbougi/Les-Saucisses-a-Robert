#include <MQTT.h>

MQTTClient mqqtClient;  // Create a MQTT client to handle messagin between object and broker

//begining of the payload string
String payload ="{";

//const char mqttServer[] = "thingsboard.cloud"; // IP adress of IDO ThingsBoard Server (Broker) in the classroom
const char mqttServer[] = "198.164.130.75"; // IP adress of IDO ThingsBoard Server (Broker) in the classroom
const int mqttServerPort = 1883; // broker mqtt port

const char key[] = "JdqUzLjqoWncfybnP91X"; // broker access token
const char secret[] = ""; // broker secret
const char device[] = "c4411a80-c872-11eb-98bf-cd7a07e42299"; // broker device identifier


MQTTClient mqttClient;  // Create a MQTT client to handle messagin between object and broker

void MQTTConnect() {
  
  mqqtClient.begin(mqttServer, mqttServerPort, wifiClient);
  Serial.print("Connecting to broker...");
  
  while (!mqqtClient.connect(device, key, secret)) {
    Serial.print(".");
    delay(1000);
  }

  Serial.println("\nConnected to MQTT!\n");

}

void appendPayload(String Name, String Val)
{

  if( payload != "{")
  {
    payload += ",";  
  }
  
  payload += "\"";
  payload += Name; 
  payload += "\": ";
  payload += Val;
  

  //Serial.println(payload);
  
}

void sendPayload()
{
  char attributes[200];
  payload += "}";
  payload.toCharArray(attributes, 200);
  mqqtClient.publish("v1/devices/me/telemetry", attributes);
  Serial.println(payload);
  payload="{";
  
}

void payloadDetails()
{

  Serial.print("payload -> ");
  Serial.println(payload);
  Serial.print("payload length -> ");
  Serial.println(payload.length());
  
}
